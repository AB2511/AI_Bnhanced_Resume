require("dotenv").config();
const axios = require("axios");
const Resume = require("../models/Resume.model");

// ✅ Function to Call AI with Proper JSON Output (Retries on Rate Limits)
const GPTFunction = async (category, userInput, retries = 3) => {
  while (retries > 0) {
    try {
      console.log(`🔹 Sending AI request for ${category}:`, userInput);

      const response = await axios.post(
        "https://openrouter.ai/api/v1/chat/completions",
        {
          model: "deepseek/deepseek-r1:free",
          messages: [
            {
              role: "user",
              content: `Enhance this ${category}, keeping user-provided details:
                User Input: ${JSON.stringify(userInput)}
                Return **only valid JSON**, no extra text, in this format:
                ${category === "summary" ? '{"summary": "Optimized summary"}' 
                  : category === "experience" ? '[{"title": "Software Engineer", "companyName": "Company"}]' 
                  : category === "skills" ? '["JavaScript", "React", "Node.js"]' 
                  : category === "achievements" ? '[{"keyAchievements": "Award", "describe": "Won"}]' 
                  : category === "certifications" ? '[{"certificates": "AWS", "link": "https://certificate.com"}]' 
                  : category === "projects" ? '[{"pname": "E-commerce", "pdate": "2022"}]' 
                  : "[]" }
              `
            }
          ]
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
            "Content-Type": "application/json"
          }
        }
      );

      // ✅ Check if AI response is valid
      if (!response.data?.choices?.[0]?.message?.content) {
        console.error(`❌ AI response for ${category} is empty or malformed`);
        return userInput; // Keep original data if AI fails
      }

      let aiResponse = response.data.choices[0].message.content.trim();
      aiResponse = aiResponse.replace(/```json|```/g, "").trim(); // ✅ Clean response

      try {
        const parsedResponse = JSON.parse(aiResponse);
        if (!parsedResponse || (Array.isArray(parsedResponse) && parsedResponse.length === 0)) {
          console.warn(`❌ AI returned an empty response for ${category}, keeping original data.`);
          return userInput;
        }
        return parsedResponse;
      } catch (error) {
        console.error(`❌ Error parsing AI response for ${category}:`, error);
        return userInput; // ✅ Keep original data if parsing fails
      }

    } catch (error) {
      if (error.response && error.response.status === 429) {
        console.warn(`⏳ AI rate limited (429). Retrying in 5 seconds...`);
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait 5s before retry
        retries--;
      } else {
        console.error(`❌ AI Error for ${category}:`, error.response ? error.response.data : error.message);
        return userInput;
      }
    }
  }

  console.error(`❌ AI failed for ${category} after retries. Keeping original data.`);
  return userInput;
};
// ✅ Create a Resume
const createResume = async (req, res) => {
  try {
    console.log("🔹 Received Resume Data:", req.body);

    if (!req.body.resumeData) {
      return res.status(400).json({ message: "Resume data is required" });
    }

    const { email } = req.body.resumeData;
    if (!email) {
      return res.status(400).json({ message: "Email is required to prevent duplicate resumes" });
    }

    // ✅ Check if a resume already exists for this email
    const existingResume = await Resume.findOne({ email });
    if (existingResume) {
      return res.status(409).json({ message: "Resume already exists for this email", data: existingResume });
    }

    const newResume = new Resume(req.body.resumeData);
    const savedResume = await newResume.save();

    console.log("✅ Created Resume ID:", savedResume._id);
    res.status(201).json({ message: "Resume created successfully", data: savedResume });
  } catch (error) {
    console.error("❌ Error creating resume:", error);
    res.status(500).json({ message: "Error processing request", error: error.message });
  }
};


// ✅ Save Resume (Update or Create)
const saveResume = async (req, res) => {
  try {
    const resumeData = req.body.resumeData;
    if (!resumeData) {
      return res.status(400).json({ message: "Resume data is required" });
    }

    console.log("🔹 Received Resume Data for Saving:", resumeData);

    // ✅ Ensure workHistory is correctly mapped to experience
    const formattedResume = {
      name: resumeData.name || "No Name Provided",
      role: resumeData.role || "No Role Provided",
      phone: resumeData.phone || "No Phone Provided",
      email: resumeData.email || "No Email Provided",
      linkedin: resumeData.linkedin || "No LinkedIn Provided",
      location: resumeData.location || "No Location Provided",
      summary: resumeData.summary || "No Summary Provided",
      experience: Array.isArray(resumeData.experience) && resumeData.experience.length
        ? resumeData.experience
        : Array.isArray(resumeData.workHistory) ? resumeData.workHistory : [],
      education: Array.isArray(resumeData.education) ? resumeData.education : [],
      skills: Array.isArray(resumeData.skills) ? resumeData.skills : [],
      achievements: Array.isArray(resumeData.achievements) ? resumeData.achievements : [],
      certifications: Array.isArray(resumeData.certifications) ? resumeData.certifications : [],
      projects: Array.isArray(resumeData.projects) ? resumeData.projects : []
    };

    let savedResume;

    if (resumeData._id) {
      // ✅ Update existing resume
      savedResume = await Resume.findByIdAndUpdate(resumeData._id, formattedResume, { new: true });
      if (!savedResume) {
        return res.status(404).json({ message: "Resume not found for update" });
      }
    } else {
      // ✅ Create a new resume
      const newResume = new Resume(formattedResume);
      savedResume = await newResume.save();
    }

    console.log("✅ Resume saved successfully:", savedResume);
    res.status(200).json({ message: "Resume saved successfully", data: savedResume });

  } catch (error) {
    console.error("❌ Error saving resume:", error);
    res.status(500).json({ message: "Error saving resume", error: error.message });
  }
};

// ✅ Enhance Resume and Save
const enhanceAndSaveResume = async (req, res) => {
  try {
    const { resumeId } = req.body;
    console.log("🔹 Received resume ID:", resumeId);

    if (!resumeId) {
      return res.status(400).json({ message: "Resume ID is required" });
    }

    const resume = await Resume.findById(resumeId);
    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    console.log("✅ Found Resume Data:", resume);

    const categories = ["summary", "experience", "skills", "achievements", "certifications", "projects"];
    const enhancedData = {};

    for (const category of categories) {
      const aiResponse = await GPTFunction(category, resume[category]);
      console.log(`🔹 AI Response for ${category}:`, aiResponse);

      if (aiResponse && (!Array.isArray(aiResponse) || aiResponse.length > 0)) {
        enhancedData[category] = aiResponse; // ✅ Only update if AI returns valid data
      } else {
        console.warn(`❌ AI enhancement failed for ${category}, keeping original data.`);
        enhancedData[category] = resume[category]; // ✅ Keep original data if AI fails
      }
    }

    // ✅ Fix MongoDB Update Issue
    const updatedResume = await Resume.findByIdAndUpdate(
      resume._id,
      {
        summary: enhancedData.summary?.summary || resume.summary,  // ✅ Fix: Extracting string value
        experience: enhancedData.experience || resume.experience,
        skills: enhancedData.skills || resume.skills,
        achievements: enhancedData.achievements || resume.achievements,
        certifications: enhancedData.certifications || resume.certifications,
        projects: enhancedData.projects || resume.projects
      },
      { new: true }
    );

    console.log("✅ Resume enhanced and updated in DB:", updatedResume);

    res.json({
      message: "Resume enhanced successfully",
      data: updatedResume
    });

  } catch (error) {
    console.error("❌ Error enhancing resume:", error);
    res.status(500).json({ message: "Error processing request", error: error.message });
  }
};




// ✅ Export Functions
module.exports = { createResume, saveResume, enhanceAndSaveResume };

