const express = require("express");
const router = express.Router();
const { createResume, enhanceAndSaveResume, saveResume } = require("../controllers/resumeController");

// ✅ Corrected routes
router.post("/create", createResume); // For initial creation
router.post("/save", saveResume);     // For updates
router.post("/enhance", enhanceAndSaveResume);

module.exports = router;
