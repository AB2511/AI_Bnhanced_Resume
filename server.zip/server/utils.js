const { OpenAI } = require("openai");

// OpenAI client setup
const openai = new OpenAI({
  apiKey: process.env.SECRET_KEY, // Assuming the API key is stored in your .env file
});

// Function to generate unique IDs for the resume entries
const generateId = () => {
  return Math.random().toString(36).substring(2, 15);
};

// GPT-4 function to call the OpenAI API
const GPTFunction = async (prompt) => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4", // Using GPT-4 model
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: prompt },
      ],
      temperature: 1,
      max_tokens: 2048,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0
    });
    return response.choices[0].message.content.trim(); // Extracting the text response
  } catch (error) {
    console.error("Error fetching response:", error);
    return null;
  }
};

module.exports = { generateId, GPTFunction };
