const mongoose = require("mongoose");

const resumeSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    role: { type: String, required: false }, // ✅ Not always needed
    phone: { type: String, required: false },
    email: { type: String, required: false },
    linkedin: { type: String, required: false },
    location: { type: String, required: false },
    summary: { type: String, required: false },
    experience: [
      {
        title: { type: String, required: false },
        companyName: { type: String, required: false },
        date: { type: String, required: false },
        companyLocation: { type: String, required: false },
        description: { type: String, required: false },
        accomplishment: { type: String, required: false },
      },
    ],
    education: [
      {
        degree: { type: String, required: false },
        institution: { type: String, required: false },
        duration: { type: String, required: false },
        grade: { type: String, required: false },
      },
    ],
    achievements: [
      {
        keyAchievements: { type: String, required: false },
        describe: { type: String, required: false },
      },
    ],
    certifications: [
      {
        certificates: { type: String, required: false },
        link: { type: String, required: false },
      },
    ],
    skills: { type: [String], default: [] }, // ✅ Allows empty skills
    projects: [
      {
        pname: { type: String, required: false },
        pdate: { type: String, required: false },
        psummary: { type: String, required: false },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Resume", resumeSchema);
