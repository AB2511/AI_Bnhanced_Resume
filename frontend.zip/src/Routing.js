import React from 'react';
import { BrowserRouter as Router,Route,Routes } from 'react-router-dom';

export default function Routing() {
  return (
    <div>
        <Router>
            <Routes>

            </Routes>
        </Router>
    </div>
  )
}
