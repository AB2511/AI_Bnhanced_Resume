import React, { useState } from "react";
import axios from "axios";
import html2pdf from "html2pdf.js";
import "./EditableTemplate.css";

const EditableTemplate = () => {
  const [resumeData, setResumeData] = useState({
    _id: null, // Ensures resume is saved before enhancing
    fullName: "Your Name",
    currentPosition: "Your Job Title",
    phone: "",
    email: "",
    linkedin: "",
    location: "",
    summary: "Enter your professional summary...",
    workHistory: [],
    education: [],
    achievements: [],
    skills: [],
    interests: [],
    courses: [],
  });

  const [showButtons, setShowButtons] = useState(true);

  // ✅ Handle Editable Inputs
  const handleInputChange = (section, field, value, index = null) => {
    if (index !== null) {
      const updatedSection = [...resumeData[section]];
      updatedSection[index][field] = value;
      setResumeData({ ...resumeData, [section]: updatedSection });
    } else {
      setResumeData({ ...resumeData, [field]: value });
    }
  };

  // ✅ Add New Section
  const handleAddSection = (section, defaultValues) => {
    setResumeData({ ...resumeData, [section]: [...resumeData[section], defaultValues] });
  };

  // ✅ Remove Section
  const handleRemoveSection = (section, index) => {
    const updatedSection = [...resumeData[section]];
    updatedSection.splice(index, 1);
    setResumeData({ ...resumeData, [section]: updatedSection });
  };

  // ✅ Save Resume to Database
  const saveResume = async () => {
    try {
      console.log("🔹 Saving resume...");

      const response = await axios.post("http://localhost:5000/api/resume/create", resumeData);

      if (response.data && response.data.data) {
        console.log("✅ Created Resume ID:", response.data.data._id);
        setResumeData({ ...resumeData, _id: response.data.data._id });
        alert("Resume saved successfully!");
      } else {
        alert("Error saving resume.");
      }
    } catch (error) {
      console.error("❌ Error saving resume:", error);
      alert("Error saving resume.");
    }
  };

  // ✅ Enhance Resume with AI
  const enhanceResume = async () => {
    if (!resumeData._id) {
      alert("Please save your resume before enhancing it.");
      return;
    }

    try {
      console.log("🔹 Enhancing resume with ID:", resumeData._id);

      const response = await axios.post("http://localhost:5000/api/resume/enhance", {
        resumeId: resumeData._id,
      });

      console.log("✅ AI Response:", response.data);

      if (response.data && response.data.data) {
        setResumeData(response.data.data);
        alert("Resume enhanced successfully!");
      } else {
        alert("AI enhancement failed. Please try again.");
      }
    } catch (error) {
      console.error("❌ Error enhancing resume:", error);
      alert("Error enhancing resume");
    }
  };

  // ✅ Download Resume as PDF
  const handleDownload = () => {
    setShowButtons(false);
    setTimeout(() => {
      const resumeContent = document.getElementById("resumeContent");
      const options = {
        filename: "resume.pdf",
        html2canvas: { scale: 2 },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
      };
      html2pdf().from(resumeContent).set(options).save().then(() => {
        setShowButtons(true);
      });
    }, 100);
  };

  return (
    <div>
      <div className="resume-container" id="resumeContent">
        {/* Header Section */}
        <div className="header">
          <h1 contentEditable onBlur={(e) => handleInputChange(null, "fullName", e.target.textContent)}>
            {resumeData.fullName}
          </h1>
          <p contentEditable onBlur={(e) => handleInputChange(null, "currentPosition", e.target.textContent)}>
            {resumeData.currentPosition}
          </p>
          <div className="contact-info">
            <span contentEditable onBlur={(e) => handleInputChange(null, "phone", e.target.textContent)}>
              {resumeData.phone || "Phone Number"}
            </span>
            <span contentEditable onBlur={(e) => handleInputChange(null, "email", e.target.textContent)}>
              {resumeData.email || "Email"}
            </span>
            <span contentEditable onBlur={(e) => handleInputChange(null, "linkedin", e.target.textContent)}>
              {resumeData.linkedin || "LinkedIn"}
            </span>
            <span contentEditable onBlur={(e) => handleInputChange(null, "location", e.target.textContent)}>
              {resumeData.location || "Location"}
            </span>
          </div>
        </div>

        {/* Summary Section */}
        <div className="section">
          <h2>Summary</h2>
          <p contentEditable onBlur={(e) => handleInputChange(null, "summary", e.target.textContent)}>
            {resumeData.summary}
          </p>
        </div>

        {/* Work History Section */}
        <div className="section">
          <h2>Work History</h2>
          {resumeData.workHistory.map((job, index) => (
            <div key={index}>
              <h3 contentEditable onBlur={(e) => handleInputChange("workHistory", "name", e.target.textContent, index)}>
                {job.name || "Company Name"}
              </h3>
              <p contentEditable onBlur={(e) => handleInputChange("workHistory", "position", e.target.textContent, index)}>
                {job.position || "Job Title"}
              </p>
              <p>
                <input type="date" value={job.startDate || ""} onChange={(e) => handleInputChange("workHistory", "startDate", e.target.value, index)} /> - 
                <input type="date" value={job.endDate || ""} onChange={(e) => handleInputChange("workHistory", "endDate", e.target.value, index)} />
              </p>
              <button onClick={() => handleRemoveSection("workHistory", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("workHistory", { name: "", position: "", startDate: "", endDate: "" })}>
            + Add Work History
          </button>
        </div>

        {/* Education Section */}
        <div className="section">
          <h2>Education</h2>
          {resumeData.education.map((edu, index) => (
            <div key={index}>
              <h3 contentEditable onBlur={(e) => handleInputChange("education", "school", e.target.textContent, index)}>
                {edu.school || "School Name"}
              </h3>
              <p contentEditable onBlur={(e) => handleInputChange("education", "degree", e.target.textContent, index)}>
                {edu.degree || "Degree"}
              </p>
              <button onClick={() => handleRemoveSection("education", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("education", { school: "", degree: "" })}>+ Add Education</button>
        </div>

        {/* Achievements Section */}
        <div className="section">
          <h2>Achievements</h2>
          {resumeData.achievements.map((achievement, index) => (
            <div key={index}>
              <p contentEditable onBlur={(e) => handleInputChange("achievements", "description", e.target.textContent, index)}>
                {achievement.description || "Achievement Description"}
              </p>
              <button onClick={() => handleRemoveSection("achievements", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("achievements", { description: "" })}>+ Add Achievement</button>
        </div>

        {/* Skills Section */}
        <div className="section">
          <h2>Skills</h2>
          {resumeData.skills.map((skill, index) => (
            <div key={index}>
              <p contentEditable onBlur={(e) => handleInputChange("skills", "name", e.target.textContent, index)}>
                {skill.name || "Skill Name"}
              </p>
              <button onClick={() => handleRemoveSection("skills", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("skills", { name: "" })}>+ Add Skill</button>
        </div>

        {/* Interests Section */}
        <div className="section">
          <h2>Interests</h2>
          {resumeData.interests.map((interest, index) => (
            <div key={index}>
              <p contentEditable onBlur={(e) => handleInputChange("interests", "name", e.target.textContent, index)}>
                {interest.name || "Interest Name"}
              </p>
              <button onClick={() => handleRemoveSection("interests", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("interests", { name: "" })}>+ Add Interest</button>
        </div>

        {/* Courses Section */}
        <div className="section">
          <h2>Courses</h2>
          {resumeData.courses.map((course, index) => (
            <div key={index}>
              <h3 contentEditable onBlur={(e) => handleInputChange("courses", "title", e.target.textContent, index)}>
                {course.title || "Course Title"}
              </h3>
              <p contentEditable onBlur={(e) => handleInputChange("courses", "description", e.target.textContent, index)}>
                {course.description || "Course Description"}
              </p>
              <button onClick={() => handleRemoveSection("courses", index)}>Remove</button>
            </div>
          ))}
          <button onClick={() => handleAddSection("courses", { title: "", description: "" })}>+ Add Course</button>
        </div>
      </div>

      {/* Buttons */}
      {showButtons && (
        <>
          <button onClick={saveResume} className="save-button">Save Resume</button>
          <button onClick={enhanceResume} className="enhance-button">Enhance Resume with AI</button>
          <button onClick={handleDownload}>Download Resume</button>
        </>
      )}
    </div>
  );
};

export default EditableTemplate;