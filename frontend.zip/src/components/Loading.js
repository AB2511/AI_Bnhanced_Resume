import React from 'react';

const Loading=() =>{
  return (
    <div className='app'>
      <h1>Loding,please wait...</h1>
    </div>
  )
}

export default Loading;