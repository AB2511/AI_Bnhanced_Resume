import React from 'react';
import { Link } from 'react-router-dom';
// import template1 from '../images/template1.jpg';
// import template2 from '../images/template2.jpg';
// import template3 from '../images/template3.jpg';
// import template4 from '../images/template4.jpg';
// import template5 from '../images/template5.jpg';
// import template6 from '../images/template6.jpg';
// import template7 from '../images/template7.jpg';
// import template8 from '../images/template8.jpg';
import template9 from '../images/template9.png';
import template10 from '../images/template10.png';
import template11 from '../images/template11.png';
import template13 from '../images/template13.png';
import template14 from '../images/template14.png';
import template15 from '../images/template15.png';

export default function WithoutAiTemp() {
    return (
        <div style={{marginTop:"75vh",background:"white"}}>
            <div className="container">
                <div className="row">
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template9} class="card-img-top" alt="Template" style={{width:"310px",height:"500px"}}/>
                        <div class="card-body">
                            <Link to="/input" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template10} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <Link to="/inputcreative" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template11} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <Link to="/formpage" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template13} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <Link to="/inputminimal" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template14} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <Link to="/inputmodern" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template15} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <Link to="/inputprof" class="btn btn-primary">Use This Template</Link>
                        </div>
                    </div>
                    {/* <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template7} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary">Use This Template</a>
                        </div>
                    </div>
                    <div class="card my-3 mx-4" style={{width:"auto",textAlign:"center"}} >
                        <img src={template8} class="card-img-top" alt="Template" style={{width:"20vw",height:"60vh"}}/>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary">Use This Template</a>
                        </div>
                    </div>
                    */}
                    
                </div>
            </div>
        </div>
    )
}
