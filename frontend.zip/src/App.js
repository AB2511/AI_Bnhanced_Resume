import { BrowserRouter as Router,Route,Routes } from 'react-router-dom';
import Login from './components/Login';
import Both from './components/Both';
import Home from './components/Home';
import Firstpage from './components/Firstpage';
import Suggestions from './components/Suggestion';
import Faq from './components/Faq';
import UploadPage from './components/UploadPage';
import Templates from './components/Templates';
import { useState } from 'react';
//import AfterNo from  './components/AfterNo'
import Output from './components/Output';
import TemplateNo from './components/TemplateNo';
import FormPage from './components/Formpage';
import Input from './components/Input';
import Classic from './Themes/Classic';
import Creative from './Themes/Creative';
import WithoutAi from './components/withoutAi';
import FirstWithoutAi from './components/FirstWithoutAi';
import WithoutAiTemp from './components/WithoutAiTemp';
import InputCreative from './components/InputCreative';
import InputMinimal from './components/InputMinimal';
import Minimalist from './Themes/Minimalist';
import InputModern from './components/InputModern';
import Modern from './Themes/Modern';
import InputProf from './components/InputProf';
import Professional from './Themes/Professional';
//import EditableTemplate from "./components/EditableTemplate";
import Edit_3 from './components/Edit_3';

function App() {
  const [result,setResult]= useState({"name": "John Doe",
    "position": "Software Engineer",
    "skills": ["JavaScript", "React", "Node.js"]});

  return (
    <div>
      <Router>
      <Routes>
      <Route exact path='/' element={ <Home/>}/>
     <Route exact path='/login' element={<Login/>}/>
     <Route exact path='/privacy' element={ <Both/>}/>
     <Route exact path='/faq' element={   <Faq/>}/>
     <Route exact path='/suggestion' element={ <Suggestions/>}/>
     <Route exact path='/firstpage' element={ <Firstpage/>}/>
     <Route exact path='/upload' element={ <UploadPage/>}/>
     <Route exact path='/Edit_3' element={<Edit_3 setResult={setResult}/>}/>
    <Route exact path='/output' element={<Output result={result}/>}/>
    <Route exact path='/templateno' element={<TemplateNo/>}/>
     <Route exact path='/templates' element={<Templates/>}/>
     <Route exact path='/formpage' element={<FormPage/>}/>
     <Route exact path='/firstwithoutai' element={<FirstWithoutAi/>}/>
      <Route exact path='/withoutai' element={<WithoutAi/>}/>
      <Route exact path='/withoutaitemp' element={<WithoutAiTemp/>}/>
     <Route exact path='/input' element={<Input/>}/>
     <Route exact path='/inputcreative' element={<InputCreative/>}/>
     <Route exact path='/inputminimal' element={<InputMinimal/>}/>
     <Route exact path='/inputprof' element={<InputProf/>}/>
     <Route exact path='/inputmodern' element={<InputModern/>}/>
     <Route exact path='/classictheme' element={<Classic/>}/>
     <Route exact path='/creativetheme' element={<Creative/>}/>
     <Route exact path='/minimaltheme' element={<Minimalist/>}/>
     <Route exact path='/moderntheme' element={<Modern/>}/>
     <Route exact path='/proftheme' element={<Professional/>}/>
     </Routes>
      </Router>
    </div>
  );
}

export default App;
